var express = require("express");
const {
  getAllDeskripsi,
  getDeskripsiById,
  createDeskripsi,
  updateDeskripsi,
  deleteDeskripsi,
} = require("../controllers/deskripsiController");

var router = express.Router();

router.get("/", getAllDeskripsi);
router.get("/:code", getDeskripsiById);
router.post("/create", createDeskripsi);
router.patch("/update/:code", updateDeskripsi);
router.delete("/delete/:code", deleteDeskripsi);

module.exports = router;
